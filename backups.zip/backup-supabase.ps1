$Data = Get-Date -Format "yyyy-MM-dd_HHmm"
$PastaBackup = "C:\Users\Joao Carlos\Desktop\gestor-alugueis\backups"
$ArquivoBackup = Join-Path $PastaBackup "backup_$Data.sql"

Set-Location "C:\Users\Joao Carlos\Desktop\gestor-alugueis"

npx supabase db dump --linked -f $ArquivoBackup

Get-ChildItem $PastaBackup -Filter "backup_*.sql" |
    Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-30) } |
    Remove-Item -Force