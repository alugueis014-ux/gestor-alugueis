


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE EXTENSION IF NOT EXISTS "pg_cron" WITH SCHEMA "pg_catalog";






COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."atualizar_data_modificacao"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public'
    AS $$
begin
  new.atualizado_em = now();
  return new;
end;
$$;


ALTER FUNCTION "public"."atualizar_data_modificacao"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."gerar_cobrancas_mes_atual"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_competencia date := date_trunc('month', current_date)::date;
  v_fim_mes date := (date_trunc('month', current_date) + interval '1 month - 1 day')::date;
  v_inseridos integer := 0;
begin
  insert into public.recebimentos (
    proprietario_id,
    contrato_id,
    competencia,
    data_vencimento,
    valor_previsto,
    valor_recebido,
    multa,
    juros,
    desconto,
    status
  )
  select
    c.proprietario_id,
    c.id,
    v_competencia,
    make_date(
      extract(year from v_competencia)::int,
      extract(month from v_competencia)::int,
      least(
        greatest(coalesce(c.dia_vencimento, 1), 1),
        extract(day from v_fim_mes)::int
      )
    ),
    coalesce(c.valor_aluguel, 0),
    0,
    0,
    0,
    0,
    'pendente'
  from public.contratos c
  where c.status = 'ativo'
    -- Contrato precisa existir em algum momento do mês atual.
    and c.data_inicio <= v_fim_mes
    and (c.data_fim is null or c.data_fim >= v_competencia)
    -- Proteção contra cobrança duplicada.
    and not exists (
      select 1
      from public.recebimentos r
      where r.contrato_id = c.id
        and r.competencia = v_competencia
        and coalesce(r.status, '') <> 'cancelado'
    );

  get diagnostics v_inseridos = row_count;
  return v_inseridos;
end;
$$;


ALTER FUNCTION "public"."gerar_cobrancas_mes_atual"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."anexos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "inquilino_id" "uuid",
    "contrato_id" "uuid",
    "nome_arquivo" "text" NOT NULL,
    "caminho_arquivo" "text" NOT NULL,
    "tipo_arquivo" "text",
    "tamanho_bytes" bigint,
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "anexos_check" CHECK ((("inquilino_id" IS NOT NULL) OR ("contrato_id" IS NOT NULL)))
);


ALTER TABLE "public"."anexos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."apartamentos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "predio_id" "uuid" NOT NULL,
    "numero" "text" NOT NULL,
    "situacao" "text" DEFAULT 'disponivel'::"text" NOT NULL,
    "observacoes" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "apartamentos_situacao_check" CHECK (("situacao" = ANY (ARRAY['disponivel'::"text", 'ocupado'::"text", 'reservado'::"text", 'manutencao'::"text"])))
);


ALTER TABLE "public"."apartamentos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."contratos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "inquilino_id" "uuid" NOT NULL,
    "apartamento_id" "uuid" NOT NULL,
    "valor_aluguel" numeric(12,2) NOT NULL,
    "dia_vencimento" integer NOT NULL,
    "data_inicio" "date" NOT NULL,
    "data_fim" "date",
    "status" "text" DEFAULT 'ativo'::"text" NOT NULL,
    "observacoes" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "contratos_check" CHECK ((("data_fim" IS NULL) OR ("data_fim" >= "data_inicio"))),
    CONSTRAINT "contratos_dia_vencimento_check" CHECK ((("dia_vencimento" >= 1) AND ("dia_vencimento" <= 31))),
    CONSTRAINT "contratos_status_check" CHECK (("status" = ANY (ARRAY['ativo'::"text", 'encerrado'::"text"]))),
    CONSTRAINT "contratos_valor_aluguel_check" CHECK (("valor_aluguel" >= (0)::numeric))
);


ALTER TABLE "public"."contratos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."historico" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "entidade" "text" NOT NULL,
    "entidade_id" "uuid",
    "acao" "text" NOT NULL,
    "descricao" "text",
    "dados" "jsonb",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."historico" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."inquilinos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "nome" "text" NOT NULL,
    "cpf" "text",
    "telefone" "text",
    "email" "text",
    "status" "text" DEFAULT 'ativo'::"text" NOT NULL,
    "data_saida" "date",
    "observacoes" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "inquilinos_status_check" CHECK (("status" = ANY (ARRAY['ativo'::"text", 'inativo'::"text"])))
);


ALTER TABLE "public"."inquilinos" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."perfis" (
    "id" "uuid" NOT NULL,
    "nome" "text",
    "email" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."perfis" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."predios" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "nome" "text" NOT NULL,
    "endereco" "text",
    "observacoes" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."predios" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."recebimentos" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "proprietario_id" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "contrato_id" "uuid" NOT NULL,
    "competencia" "date" NOT NULL,
    "data_vencimento" "date" NOT NULL,
    "valor_previsto" numeric(12,2) NOT NULL,
    "valor_recebido" numeric(12,2) DEFAULT 0 NOT NULL,
    "multa" numeric(12,2) DEFAULT 0 NOT NULL,
    "juros" numeric(12,2) DEFAULT 0 NOT NULL,
    "desconto" numeric(12,2) DEFAULT 0 NOT NULL,
    "data_pagamento" "date",
    "forma_pagamento" "text",
    "status" "text" DEFAULT 'pendente'::"text" NOT NULL,
    "observacoes" "text",
    "criado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    "atualizado_em" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "recebimentos_desconto_check" CHECK (("desconto" >= (0)::numeric)),
    CONSTRAINT "recebimentos_forma_pagamento_check" CHECK ((("forma_pagamento" IS NULL) OR ("forma_pagamento" = ANY (ARRAY['pix'::"text", 'transferencia'::"text", 'dinheiro'::"text", 'boleto'::"text", 'outro'::"text"])))),
    CONSTRAINT "recebimentos_juros_check" CHECK (("juros" >= (0)::numeric)),
    CONSTRAINT "recebimentos_multa_check" CHECK (("multa" >= (0)::numeric)),
    CONSTRAINT "recebimentos_status_check" CHECK (("status" = ANY (ARRAY['pendente'::"text", 'pago'::"text", 'atrasado'::"text", 'cancelado'::"text"]))),
    CONSTRAINT "recebimentos_valor_previsto_check" CHECK (("valor_previsto" >= (0)::numeric)),
    CONSTRAINT "recebimentos_valor_recebido_check" CHECK (("valor_recebido" >= (0)::numeric))
);


ALTER TABLE "public"."recebimentos" OWNER TO "postgres";


ALTER TABLE ONLY "public"."anexos"
    ADD CONSTRAINT "anexos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."apartamentos"
    ADD CONSTRAINT "apartamentos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."apartamentos"
    ADD CONSTRAINT "apartamentos_predio_id_numero_key" UNIQUE ("predio_id", "numero");



ALTER TABLE ONLY "public"."contratos"
    ADD CONSTRAINT "contratos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."historico"
    ADD CONSTRAINT "historico_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."inquilinos"
    ADD CONSTRAINT "inquilinos_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."perfis"
    ADD CONSTRAINT "perfis_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."predios"
    ADD CONSTRAINT "predios_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."recebimentos"
    ADD CONSTRAINT "recebimentos_contrato_id_competencia_key" UNIQUE ("contrato_id", "competencia");



ALTER TABLE ONLY "public"."recebimentos"
    ADD CONSTRAINT "recebimentos_pkey" PRIMARY KEY ("id");



CREATE INDEX "anexos_proprietario_idx" ON "public"."anexos" USING "btree" ("proprietario_id");



CREATE INDEX "apartamentos_predio_idx" ON "public"."apartamentos" USING "btree" ("predio_id");



CREATE INDEX "apartamentos_proprietario_idx" ON "public"."apartamentos" USING "btree" ("proprietario_id");



CREATE UNIQUE INDEX "contrato_ativo_por_apartamento_idx" ON "public"."contratos" USING "btree" ("apartamento_id") WHERE ("status" = 'ativo'::"text");



CREATE INDEX "contratos_apartamento_idx" ON "public"."contratos" USING "btree" ("apartamento_id");



CREATE INDEX "contratos_inquilino_idx" ON "public"."contratos" USING "btree" ("inquilino_id");



CREATE INDEX "contratos_proprietario_idx" ON "public"."contratos" USING "btree" ("proprietario_id");



CREATE INDEX "contratos_status_idx" ON "public"."contratos" USING "btree" ("status");



CREATE INDEX "historico_entidade_idx" ON "public"."historico" USING "btree" ("entidade", "entidade_id");



CREATE INDEX "historico_proprietario_idx" ON "public"."historico" USING "btree" ("proprietario_id");



CREATE INDEX "inquilinos_nome_idx" ON "public"."inquilinos" USING "btree" ("nome");



CREATE INDEX "inquilinos_proprietario_idx" ON "public"."inquilinos" USING "btree" ("proprietario_id");



CREATE INDEX "inquilinos_status_idx" ON "public"."inquilinos" USING "btree" ("status");



CREATE INDEX "predios_proprietario_idx" ON "public"."predios" USING "btree" ("proprietario_id");



CREATE INDEX "recebimentos_competencia_idx" ON "public"."recebimentos" USING "btree" ("competencia");



CREATE INDEX "recebimentos_contrato_idx" ON "public"."recebimentos" USING "btree" ("contrato_id");



CREATE INDEX "recebimentos_proprietario_idx" ON "public"."recebimentos" USING "btree" ("proprietario_id");



CREATE INDEX "recebimentos_status_idx" ON "public"."recebimentos" USING "btree" ("status");



CREATE OR REPLACE TRIGGER "atualizar_apartamentos_em" BEFORE UPDATE ON "public"."apartamentos" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



CREATE OR REPLACE TRIGGER "atualizar_contratos_em" BEFORE UPDATE ON "public"."contratos" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



CREATE OR REPLACE TRIGGER "atualizar_inquilinos_em" BEFORE UPDATE ON "public"."inquilinos" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



CREATE OR REPLACE TRIGGER "atualizar_perfis_em" BEFORE UPDATE ON "public"."perfis" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



CREATE OR REPLACE TRIGGER "atualizar_predios_em" BEFORE UPDATE ON "public"."predios" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



CREATE OR REPLACE TRIGGER "atualizar_recebimentos_em" BEFORE UPDATE ON "public"."recebimentos" FOR EACH ROW EXECUTE FUNCTION "public"."atualizar_data_modificacao"();



ALTER TABLE ONLY "public"."anexos"
    ADD CONSTRAINT "anexos_contrato_id_fkey" FOREIGN KEY ("contrato_id") REFERENCES "public"."contratos"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."anexos"
    ADD CONSTRAINT "anexos_inquilino_id_fkey" FOREIGN KEY ("inquilino_id") REFERENCES "public"."inquilinos"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."anexos"
    ADD CONSTRAINT "anexos_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."apartamentos"
    ADD CONSTRAINT "apartamentos_predio_id_fkey" FOREIGN KEY ("predio_id") REFERENCES "public"."predios"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."apartamentos"
    ADD CONSTRAINT "apartamentos_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."contratos"
    ADD CONSTRAINT "contratos_apartamento_id_fkey" FOREIGN KEY ("apartamento_id") REFERENCES "public"."apartamentos"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."contratos"
    ADD CONSTRAINT "contratos_inquilino_id_fkey" FOREIGN KEY ("inquilino_id") REFERENCES "public"."inquilinos"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."contratos"
    ADD CONSTRAINT "contratos_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."historico"
    ADD CONSTRAINT "historico_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."inquilinos"
    ADD CONSTRAINT "inquilinos_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."perfis"
    ADD CONSTRAINT "perfis_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."predios"
    ADD CONSTRAINT "predios_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."recebimentos"
    ADD CONSTRAINT "recebimentos_contrato_id_fkey" FOREIGN KEY ("contrato_id") REFERENCES "public"."contratos"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."recebimentos"
    ADD CONSTRAINT "recebimentos_proprietario_id_fkey" FOREIGN KEY ("proprietario_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



CREATE POLICY "Atualizar o próprio perfil" ON "public"."perfis" FOR UPDATE TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "id"));



CREATE POLICY "Criar o próprio perfil" ON "public"."perfis" FOR INSERT TO "authenticated" WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "id"));



CREATE POLICY "Gerenciar próprio histórico" ON "public"."historico" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios anexos" ON "public"."anexos" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios apartamentos" ON "public"."apartamentos" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios contratos" ON "public"."contratos" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios inquilinos" ON "public"."inquilinos" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios prédios" ON "public"."predios" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Gerenciar próprios recebimentos" ON "public"."recebimentos" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id")) WITH CHECK ((( SELECT "auth"."uid"() AS "uid") = "proprietario_id"));



CREATE POLICY "Ver o próprio perfil" ON "public"."perfis" FOR SELECT TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") = "id"));



ALTER TABLE "public"."anexos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "anexos_do_usuario" ON "public"."anexos" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));



ALTER TABLE "public"."apartamentos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "apartamentos_do_usuario" ON "public"."apartamentos" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));



ALTER TABLE "public"."contratos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "contratos_do_usuario" ON "public"."contratos" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));



ALTER TABLE "public"."historico" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."inquilinos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "inquilinos_do_usuario" ON "public"."inquilinos" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));



ALTER TABLE "public"."perfis" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."predios" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "predios_do_usuario" ON "public"."predios" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));



ALTER TABLE "public"."recebimentos" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "recebimentos_do_usuario" ON "public"."recebimentos" TO "authenticated" USING (("auth"."uid"() = "proprietario_id")) WITH CHECK (("auth"."uid"() = "proprietario_id"));





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";





GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";











































































































































































GRANT ALL ON FUNCTION "public"."atualizar_data_modificacao"() TO "anon";
GRANT ALL ON FUNCTION "public"."atualizar_data_modificacao"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."atualizar_data_modificacao"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."gerar_cobrancas_mes_atual"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."gerar_cobrancas_mes_atual"() TO "anon";
GRANT ALL ON FUNCTION "public"."gerar_cobrancas_mes_atual"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."gerar_cobrancas_mes_atual"() TO "service_role";
























GRANT ALL ON TABLE "public"."anexos" TO "anon";
GRANT ALL ON TABLE "public"."anexos" TO "authenticated";
GRANT ALL ON TABLE "public"."anexos" TO "service_role";



GRANT ALL ON TABLE "public"."apartamentos" TO "anon";
GRANT ALL ON TABLE "public"."apartamentos" TO "authenticated";
GRANT ALL ON TABLE "public"."apartamentos" TO "service_role";



GRANT ALL ON TABLE "public"."contratos" TO "anon";
GRANT ALL ON TABLE "public"."contratos" TO "authenticated";
GRANT ALL ON TABLE "public"."contratos" TO "service_role";



GRANT ALL ON TABLE "public"."historico" TO "anon";
GRANT ALL ON TABLE "public"."historico" TO "authenticated";
GRANT ALL ON TABLE "public"."historico" TO "service_role";



GRANT ALL ON TABLE "public"."inquilinos" TO "anon";
GRANT ALL ON TABLE "public"."inquilinos" TO "authenticated";
GRANT ALL ON TABLE "public"."inquilinos" TO "service_role";



GRANT ALL ON TABLE "public"."perfis" TO "anon";
GRANT ALL ON TABLE "public"."perfis" TO "authenticated";
GRANT ALL ON TABLE "public"."perfis" TO "service_role";



GRANT ALL ON TABLE "public"."predios" TO "anon";
GRANT ALL ON TABLE "public"."predios" TO "authenticated";
GRANT ALL ON TABLE "public"."predios" TO "service_role";



GRANT ALL ON TABLE "public"."recebimentos" TO "anon";
GRANT ALL ON TABLE "public"."recebimentos" TO "authenticated";
GRANT ALL ON TABLE "public"."recebimentos" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































